﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Reflection;

namespace WisconsinExam.Services
{
    public interface ISettingService
    {
        T GetValue<T>(string key);
        bool SetValue(string key, object data);
        Dictionary<string, object> Get();
    }
    public class SettingService : ISettingService
    {
        private Dictionary<string, object> _data = new Dictionary<string, object>();
        public SettingService()
        {
            loadData();
        }

        public Dictionary<string, object> Get()
        {
            return _data;
        }
        public T GetValue<T>(string key)
        {
            if (_data.ContainsKey(key))
            {
                var value = _data[key];
                if (value == null)
                    return default(T);
                Type t = value.GetType();
                if (!t.IsByRef)
                {
                    return (T)value;
                }
                return JsonConvert.DeserializeObject<T>(key);
            }
            return default(T);
        }
        public bool SetValue(string key, object data)
        {
            try
            {
                if (_data.ContainsKey(key))
                {
                    _data[key] = data;
                } else
                {
                    _data.Add(key, data);
                }
                return true;
            }
            catch
            {

            }
            return false;
        }

        private void loadData()
        {
            try
            {
                string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                string fileName = Path.Combine(path, "settings.json");
                if (File.Exists(fileName))
                {
                    string fileContent = File.ReadAllText(fileName);
                    _data = JsonConvert.DeserializeObject<Dictionary<string, object>>(fileContent);
                    return;
                }
            }
            catch
            {

            }
            _data = new Dictionary<string, object>();
        }
    }
}
