﻿using Microsoft.AspNetCore.Mvc;
using WisconsinExam.Services;
using System.Reflection;
using WisconsinExam.Models;

namespace WisconsinExam.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ExamController : ControllerBase
    {
       
        private readonly ILogger<WeatherForecastController> _logger;
        private readonly ISettingService _settings;
        public ExamController(ILogger<WeatherForecastController> logger, ISettingService settings)
        {
            _logger = logger;
            _settings = settings;
        }

        [HttpGet("Generate")]
        public string Get(int start=100, int end=1000, int step=100)
        {
            List<int> nos = new List<int>();
            for(int n=start; n<=end; n += step)
            {
                nos.Add(n);
            }
            return String.Format("Helllo-{0}", String.Join(",", nos));
        }

        [HttpGet("Settings")]
        public Dictionary<string, object> Settings()
        {
            return _settings.Get();
        }

        [HttpGet("Setting")]
        public dynamic Setting(string key)
        {
            return _settings.GetValue<string>(key);
        }

        [HttpGet("Page1")]
        public ContentResult Page1()
        {
            return new ContentResult
            {
                ContentType = "text/html",
                Content = GetHtml("Page 1", "Hello am Page 1")
            };
        }

        [HttpGet("Page2")]
        public ContentResult Page2()
        {
            return new ContentResult
            {
                ContentType = "text/html",
                Content = GetHtml("Page 2", "Hello am Page 2")
            };
        }
        [HttpPost("validation")]
        public string Validation([FromBody] MyViewModel request)
        {
            return "Valid Data Received";
        }

        private string GetHtml(string title, string head)
        {
            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string fileName = Path.Combine(path, @"content\page.html");
            string content = string.Format("<div>File Not Found - {0}</div>", title);
            if (System.IO.File.Exists(fileName))
            {
                content = System.IO.File.ReadAllText(fileName).Replace("{TITLE}", title).Replace("{HEAD}", head);
            }
           return content;

        }
    }
}