﻿using System.ComponentModel.DataAnnotations;

namespace WisconsinExam.Models
{
    public class MyViewModel : IValidatableObject
    {
        public int Priority { get; set; }
        public DateTime DateStart { get; set; }
        public DateTime DateEnd { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var diff = DateStart.Subtract(DateEnd);
            if (diff.TotalMilliseconds> 0)
            {
                yield return new ValidationResult($"Date Start should be less than Date end.");
            }
            if (Priority < 1000 && diff.TotalDays>90)
            {
                yield return new ValidationResult($"Date range should be less than or equal 90 Days.");
            }
            if (Priority >=1000 && Priority < 5000 && diff.TotalDays > 180)
            {
                yield return new ValidationResult($"Date range should be less than or equal 180 Days.");
            }
            else if(Priority>=5000 && diff.TotalDays <= 180)
            {
                yield return new ValidationResult($"Date range should be more than or equal 180 Days.");
            }
        }

    }
}
