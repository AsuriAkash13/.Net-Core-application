﻿namespace WisconsinExam.Models
{
    public abstract class BaseFilling
    {
        protected decimal _fee = 0m;
        protected string _type = null;
        protected string _code = null;

        public virtual decimal GetFilingFee()
        {
            return _fee;
        }
        public virtual string GetFilingTypeCode()
        {
            return _code;
        }
        public virtual string GetFilingType()
        {
            return _type;
        }
    }

    public class DomesticFiling : BaseFilling
    {
        
        public DomesticFiling(string type, string code, decimal fee)
        {
            this._type = type;
            this._code = code;
            this._fee = fee;
        }
    }

    public class ForeignFiling : BaseFilling
    {

        public ForeignFiling(string type, string code, decimal fee)
        {
            this._type = type;
            this._code = code;
            this._fee = fee;
        }
    }

    public class PartnershipFiling : BaseFilling
    {

        public PartnershipFiling(string type, string code, decimal fee)
        {
            this._type = type;
            this._code = code;
            this._fee = fee;
        }
    }

}
